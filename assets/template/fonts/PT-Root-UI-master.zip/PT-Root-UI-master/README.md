# PT-Root-UI
Web font for PT Root UI, designed by Vitaly Kuzmin, distributed under the SIL Open Font License. https://www.paratype.com/fonts/pt/pt-root-ui
